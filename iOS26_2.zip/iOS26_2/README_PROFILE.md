# 3105 — iOS 26.2 source profile

## Profile
- Intended OS profile: iOS 26.2
- Xcode deployment target configured in project: 26.2
- Status: source profile only; not built or device-tested here

## Important compatibility notes
This profile sets the minimum deployment target to iOS 26.2. It is not compiled or tested in this environment.

## Security/functionality scope
- Kernel exploit, jailbreak, and sandbox escape entry points are disabled in this profile.
- This does not grant access to private containers belonging to other apps.
- Safe file access should use the Files/document picker, user-provided IPA files, or documented APIs.
- Setting an iOS deployment target does not itself make newer SwiftUI APIs available on older iOS versions.

## Build on Mac
1. Open Terminal in the folder containing `ThreeOneOSFive.xcodeproj`.
2. Run `xcodebuild -list` and select the actual scheme.
3. Run `xcodebuild -scheme "ThreeOneOSFive" -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' build` (replace the scheme if `xcodebuild -list` reports another name).
4. Resolve any compiler errors before attempting Archive/IPA export. A valid signing identity is needed for an installable IPA.

Do not treat this profile as a finished IPA or as proof of compatibility until it builds and is tested on the intended OS/device.
