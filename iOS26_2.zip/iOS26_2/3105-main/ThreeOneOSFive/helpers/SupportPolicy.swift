import Foundation

/// Runtime compatibility profile only. This policy does not indicate exploit compatibility.
enum ExploitSupportPolicy {
    static let verifiedIOS17Range = "Not verified — UI profile only"
    static let verifiedIOS18Range = "Not verified — UI profile only"
    static let verifiedIOS26Range = "Not verified — UI profile only"
    static let verifiedIOS27Builds: [(beta: Int, publicBeta: Int?, build: String)] = []

    static func iOS27BetaNumber(for build: String) -> Int? { nil }
    static func iOS27PublicBetaNumber(for build: String) -> Int? { nil }

    /// Intentionally false: no kernel exploit is supported by these compatibility profiles.
    static func supportsKernelExploit(major: Int, minor: Int, patch: Int) -> Bool { false }

    static func isSupported(major: Int, minor: Int, patch: Int, build: String) -> Bool {
        guard minor >= 0, patch >= 0 else { return false }
        // Broad UI compatibility gate only. Individual APIs still need availability checks.
        if major == 15 || major == 16 { return true }
        if major == 26 { return minor >= 0 }
        if major == 27 { return minor >= 0 }
        return false
    }
}
